// Setup empty JS object to act as endpoint for all routes
let projectData = {};

// Require Express to run server and routes
const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');

// Start up an instance of app
const app = express();

/* Middleware*/
//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cors());

// Cors for cross origin allowance

// Initialize the main project folder
app.use(express.static('website'));

// Setup Server
const port = 8000;

const sever = app.listen(port, listening);

function listening(){
    console.log(`server running on port: ${port}`)
}

//get function
app.get('/allData', sendData);

function sendData(request, response){
    response.send(projectData);
}

//post function
// app.post('/addData', addData);

// function addData(request, response){
//     let data = request.body;
//     console.log('server side data', data)

//     projectData["date"] = data.date;
//     projectData["temp"] = data.temp;
//     projectData["feel"] = data.feeling;

//     response.send(projectData);
// }

app.post("/addDat", async function (req, res) {
    const body = await req.body;
    projectData = body;
    console.log(projectData);
    res.status(200).send(projectData);
});

// app.get("/all", async (req, res) => {
//     res.send(projectData);
// });

app.post('/addData', (req,res)=> {
    newEntry = {
        temp: req.body.temp,
        date: req.body.date,
        user_response: req.body.feelings
    }
    // projectData.push(newEntry);
    // console.log(projectData)
    // res.send(projectData);
    projectData = req.body;
    console.log(projectData);
    console.log("the post request is here!!!!");
});