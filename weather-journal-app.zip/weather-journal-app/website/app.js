/* Global Variables */
const generate = document.querySelector("#generate");
const zip = document.querySelector("#zip");
const feelings = document.querySelector("#feelings");
const temp = document.querySelector("#temp");

// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+'-'+ d.getDate()+'-'+ d.getFullYear();
console.log(newDate);

const baseURI = "https://api.openweathermap.org/data/2.5/weather?zip="
const key = "&appid=3aae444500d12633931a612f630eefb9";

generate.addEventListener("click", (event) => {
    event.preventDefault();
    const madeURI = `${baseURI}${zip.value}${key}`;
    console.log(madeURI);
    getData(madeURI)
    .then((data) =>{
        cureData(data)
        .then((info) =>{
            postData("/addData", info);
        });
    });
});

const getData = async (url)=> {
    try {
        const response = await fetch(url);
        const data = await response.json();
        if(data.cod == 200){
            console.log(data);
            return data;
        }else{
            console.log(data.message);
        }
    }catch(e){
        console.log("error", e)
    }
}

const cureData = async (data) =>{
    try{
        if(data.message){
            const info = data.message;
            console.log(info);
            return info;
        }else{
            const info = {
                newDate,
                feelings: feelings.value,
                temp: data.main.temp
            };
            console.log(info);
            return info;
        }
    }catch(e){
        console.error(e);
    }
}

const postData = async(url="", data={}) => {
    const result = await fetch(url, {
        method: "POST",
        credentials: "same-origin",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    });
    try {
        const response = await result.json();
        console.log(response);
        return response;
    }catch(err){
        console.error(err);
    }
};